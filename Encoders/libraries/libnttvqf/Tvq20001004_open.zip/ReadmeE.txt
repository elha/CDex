Contents:

ModEnc\ModEnc.dsw 	workspace for test encoder
ModEnc\Makefile		Makefile for Linux

TestEnc\TesEnc.dsp	project file foe test encoder
tvqenc\tvqenc.dsp	project file for encoder DLL

TestDec\TestDec.dsp	project file for test decoder
tvqdec\tvqdec.dsp	project file for decoder DLL

Manual\			manual

exec\			directory for execution
exec\Release\		executable files (*.exe, *.dll)

exec\TestEnc		encoder program for Linux
     TestDec		decoder program for Linux
     libtvqe.a		encoder static library for Linux
     libtvqd.a		decoder static library for Linux

* NOTE
Add "-a" option to unzip command on Linux systems:
# unzip -a Tvqxxxxxxxx.zip
